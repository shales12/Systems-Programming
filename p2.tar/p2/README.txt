Shreya Aleshetty (sa1660) and Harini Vujjini (hv95)

We included the extensions for directory wildcards and the Home directory. 

Testing Strategy:
Batch Mode:

Our testing strategy included creating multiple input files such as the myscript.sh with different commands in it so as to test the batch mode.
For the batch mode, we also considered testing the scenario in which there was an input file, but the file was empty. This is to ensure it terminates normally without executing any commands. 
We provided a file that contained a single command to see if it was executed successfully.
We tested with a file that contained multiple commands as well separated by newlines to check if they are executed in sequence. 
Then, we provided a file containing a mix of valid and invalid commands to check if mysh stops executing on the first invalid command. 

Interactive Mode: 
For the interactive mode, we tested several different inputs. We tried testing reaching directories that did not exist to see what the output would be. 

We had to check if mysh writes the greeting message before the first prompt when it is started in interactive mode. 
We tested if mysh writes a new prompt after executing a command and before reading the next command. 
We tested if mysh terminates properly when the 'exit' command is entered.
We tested if mysh prints the prompt 'mysh>' when the last command's exit status was zero.
We tested if mysh prints the prompt '!mysh>' when the last command's exit status was non zero.
We tested if mysh handles invalid commands by printing an appropriate error message and continuing to the next prompt. 
