cd home/user/downloads
ls -l