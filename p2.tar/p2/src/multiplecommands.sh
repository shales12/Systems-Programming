echo "this is the first command"
ls /some/directory/that/does/not/exist
echo "this is the second command"