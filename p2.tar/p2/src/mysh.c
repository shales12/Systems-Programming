#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>

#define MAX_ARGS 20
#define MAX_LENGTH 100

int executeCommand(char* arguments[], int input_fd, int output_fd);

int main() {
    char command[MAX_LENGTH];
    char* arguments[MAX_ARGS];
    int input_fd = STDIN_FILENO;
    int output_fd = STDOUT_FILENO;
    int i;

    while (1) {
        printf("mysh> ");

        if (fgets(command, MAX_LENGTH, stdin) == NULL) {
            break;
        }

        char* token = strtok(command, " \n");
        i = 0;
        while (token != NULL && i < MAX_ARGS - 1) {
            arguments[i] = token;
            token = strtok(NULL, " \n");
            i++;
        }
        arguments[i] = NULL;

        if (strcmp(arguments[0], "cd") == 0) {
            if (arguments[1] == NULL) {
                chdir(getenv("HOME"));
            } else if (chdir(arguments[1]) == -1) {
                perror("cd");
            }
            continue;
        } else if (strcmp(arguments[0], "exit") == 0) {
            exit(EXIT_SUCCESS);
        } else if (strcmp(arguments[0], "pwd") == 0) {
            char* current_working_directory = getcwd(NULL, 0);
            if (current_working_directory == NULL) {
                perror("pwd");
            } else {
                printf("%s\n", current_working_directory);
                free(current_working_directory);
            }
            continue;
        }

        for (i = 0; arguments[i] != NULL; i++) {
            if (strcmp(arguments[i], "<") == 0) {
                arguments[i] = NULL;
                i++;
                if (arguments[i] == NULL) {
                    fprintf(stderr, "Error: missing input file!\n");
                    goto end_loop;
                }
                input_fd = open(arguments[i], O_RDONLY);
                if (input_fd == -1) {
                    perror("open");
                    goto end_loop;
                }
            } else if (strcmp(arguments[i], ">") == 0) {
                arguments[i] = NULL;
                i++;
                if (arguments[i] == NULL) {
                    fprintf(stderr, "Error: missing output file!\n");
                    goto end_loop;
                }
                output_fd = open(arguments[i], O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
                if (output_fd == -1) {
                    perror("open");
                    goto end_loop;
                }
            }
        }

        if (executeCommand(arguments, input_fd, output_fd) == -1) {
            goto end_loop;
        }

        if (input_fd != STDIN_FILENO) {
            close(input_fd);
            input_fd = STDIN_FILENO;
        }
        if (output_fd != STDOUT_FILENO) {
            close(output_fd);
            output_fd = STDOUT_FILENO;
        }

    end_loop:
        for (i = 0; arguments[i] != NULL; i++) {
            arguments[i] = NULL;
        }
    }

    return EXIT_SUCCESS;
}

int executeCommand(char* arguments[], int input_fd, int output_fd) {
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return -1;
    } else if (pid == 0) {
        if (input_fd
